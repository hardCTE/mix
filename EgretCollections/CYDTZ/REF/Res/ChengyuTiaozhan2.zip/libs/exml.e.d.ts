declare class LevelIconSkin extends eui.Skin{
}
declare class SceneBeginSkin extends eui.Skin{
}
declare class SceneLevelsSkin extends eui.Skin{
}
